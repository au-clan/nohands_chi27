import sys, pathlib
sys.path.append(str(pathlib.Path(__file__).resolve().parents[2] / "demo-py" / "src"))
from utils.user import parseUser

def test_deliberate_failure():
    # Intentionally failing for W17 until parseUser handles single-name as None
    assert parseUser("Prince") == {"first": "Prince", "last": None}
