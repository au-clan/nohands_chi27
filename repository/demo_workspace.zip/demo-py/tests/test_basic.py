import sys, pathlib
sys.path.append(str(pathlib.Path(__file__).resolve().parents[2] / "demo-py" / "src"))
from utils.user import parseUser

def test_parse_user_basic():
    assert parseUser("Ada Lovelace") == {"first": "Ada", "last": "Lovelace"}
