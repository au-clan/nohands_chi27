from dataclasses import dataclass

@dataclass
class User:
    first: str
    last: str
    id: int | None = None
    role: str = "user"

DEFAULT_ROLE = "user"

def parseUser(full_name: str) -> dict:
    """Split 'First Last' into a dict (used by tests and other modules)."""
    parts = full_name.strip().split()
    if len(parts) >= 2:
        return {"first": parts[0], "last": parts[-1]}
    return {"first": parts[0], "last": ""}
