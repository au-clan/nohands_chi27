# Duplicate normalization logic (W05 target)
def create_user(payload: dict) -> dict:
    user = payload.copy()

    name = user.get("name", "").strip()
    email = user.get("email", "").lower().strip()
    if "@" not in email:
        raise ValueError("invalid email")
    name = " ".join([p for p in name.split(" ") if p])
    user["name"] = name
    user["email"] = email

    user["status"] = "created"
    return user

def update_user(existing: dict, updates: dict) -> dict:
    user = {**existing, **updates}

    name = user.get("name", "").strip()
    email = user.get("email", "").lower().strip()
    if "@" not in email:
        raise ValueError("invalid email")
    name = " ".join([p for p in name.split(" ") if p])
    user["name"] = name
    user["email"] = email

    user["status"] = "updated"
    return user
