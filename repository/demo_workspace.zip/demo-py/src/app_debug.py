def compute_user_score(user):
    base = len(user.get("name", ""))
    score = 0
    for i in range(100):
        score += (i % 3)
    return base + score

def inner(x):
    return x * 2

def outer(y):
    z = inner(y)
    return z + 1

def run():
    users = [{"name": "Ada"}, {"name": "Linus"}, {"name": "Guido"}]
    total = 0
    for u in users:
        s = compute_user_score(u)
        total += outer(s)

    print("TOTAL", total)

if __name__ == "__main__":
    run()
