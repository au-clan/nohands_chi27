from utils.main import use_parse_user

if __name__ == "__main__":
    print("demo-py app starting...")
    print(use_parse_user("Ada Lovelace"))
    print("demo-py app done.")
