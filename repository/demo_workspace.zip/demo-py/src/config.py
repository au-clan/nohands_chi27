BASE_URL = "https://api.example.com"
API_VERSION = "v1"
