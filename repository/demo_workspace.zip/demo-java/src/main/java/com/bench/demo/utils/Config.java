package com.bench.demo.utils;
public class Config {
    public static final String BASE_URL = "https://api.example.com";
}
