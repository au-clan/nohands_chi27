package com.bench.demo.repo;
public abstract class BaseRepo {
    public abstract void save(int id, String name);
    public String ping() { return "base"; }
}
