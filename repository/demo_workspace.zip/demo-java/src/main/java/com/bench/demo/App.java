package com.bench.demo;

public class App {
    public static void main(String[] args) {
        System.out.println("demo-java app");
        System.out.println(outer(5));
    }
    static int inner(int x) { return x * 2; }
    static int outer(int y) { int z = inner(y); return z + 1; } // W26 step into/out
}
