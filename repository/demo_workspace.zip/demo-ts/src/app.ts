/* eslint-disable no-console */ // linter will complain due to .eslintrc (W31)
import express from 'express';
import type { Request, Response } from 'express';

const app = express();
const port = 3000;

// W30: add new endpoints here (e.g., GET /api/ping returning { ok: true })
app.get('/', (_req: Request, res: Response) => {
  res.send('demo-ts server running');
});

// W30: simple health endpoint for frontend and manual checks
app.get('/api/ping', (_req: Request, res: Response) => {
  res.json({ ok: true });
});

function inner(x: number) { return x * 2; }
function outer(y: number) { const z = inner(y); return z + 1; }

function loopDemo(): number {
  let total = 0;
  let i = 0;
  while (i < 100) { // W25: conditional breakpoint i > 50
    total += i % 3;
    i += 1;
  }
  return outer(total);
}

app.get('/compute', (_req: Request, res: Response) => {
  const result = loopDemo();
  console.log('COMPUTE', result); // violates 'no-console' until W31
  res.json({ result });
});

app.listen(port, () => {
  console.log(`demo-ts listening on http://localhost:${port}`);
});