export abstract class BaseRepo {
  abstract save(user: { id: number; name: string }): Promise<void>;
  ping(): string {
    return 'base';
  }
}