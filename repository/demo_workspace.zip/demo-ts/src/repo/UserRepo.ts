export interface UserRepo {
  findById(id: number): Promise<{ id: number; name: string } | null>;
  save(user: { id: number; name: string }): Promise<void>;
}