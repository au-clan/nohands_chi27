import { BaseRepo } from './BaseRepo.js';

export class CsvUserRepo extends BaseRepo {
  async save(user: { id: number; name: string }): Promise<void> {
    // pretend to write CSV
    void user;
  }
  override ping(): string {
    return 'csv';
  }
}