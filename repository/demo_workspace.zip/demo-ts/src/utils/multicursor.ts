/**
 * W36: Use multi-cursor to rename only these three placeholders.
 */
const PLACEHOLDER = 'target';
const PLACEHOLDER_2 = 'target';
const PLACEHOLDER_3 = 'target';
// Similar strings that should NOT be changed:
const NOT_TARGET = 'targetish';
const another = 'TARGET';